import React from 'react'
// import { useEffect } from 'react'
// import { useStoreState } from '../../store/context'
// import { fetchEvent } from '../../utility/getEvents'
// import Pagination from '../Pagination'

const Discover = () => {

  return (
      <div className="discover">
        <h1 style={{
          textAlign:'center',
          fontFamily:'Algerian'
        }}> Discover Events </h1> 
      </div>
  )
}

export default Discover
